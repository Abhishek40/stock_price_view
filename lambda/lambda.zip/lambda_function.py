import requests
import time

stock_name = "MSFT"
api_key = "88b3e97efb4e46adb0a89d4295a8ec11"

def get_stock_price(stock_symbol, api):
    url = f"https://api.twelvedata.com/price?symbol={stock_symbol}&apikey={api}"
    res = requests.get(url).json()
    print(res)

get_stock_price(stock_name,api_key)